import java.time.*;
import java.time.temporal.*;
import static java.time.DayOfWeek.*;
import static java.time.temporal.TemporalAdjusters.*;


public class EX_23 {

	public static void main(String[] args) {
		LocalDate today = LocalDate.now();
		LocalDate myBirthday = LocalDate.of(2000, 12, 31);
		Period pe = today.until(myBirthday);
		Period pe1 = Period.between(today, myBirthday);
		long dday = today.until(myBirthday, ChronoUnit.YEARS);
		System.out.println(pe1);
		System.out.println(pe);
		System.out.println(dday);
		
	}
	
	
}
