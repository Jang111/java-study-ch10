import java.text.*;

public class EX_09 {

	public static void main(String[] args) {
		DecimalFormat df = new DecimalFormat("#,###.##");
		DecimalFormat df2 = new DecimalFormat("#.###E0");
		
//		int i=5;
//		Integer iObj = new Integer(7);
//		
//		int sum = iObj; // �����ڽ�  int sum = iObj.intValue();
//		System.out.println(sum);
		
		try {
			Number num = df.parse("1,234,567.89");
			System.out.print("1,234,567.89"+" -> ");
			
			double d = num.doubleValue();
			System.out.print(d+" -> ");
			
			System.out.println(df2.format(num));
		}catch(Exception e) {
			e.printStackTrace();
		}
	}
}
