import java.text.*;
import java.util.*;
public class EX_13 {

	public static void main(String[] args) {
		String pattern = "yyyy/MM/dd";
		DateFormat df = new SimpleDateFormat(pattern);
		Scanner sc = new Scanner(System.in);
		
		Date inDate = null;
		System.out.println("��¥��"+pattern+"�� ���·� �Է����ּ���.");
		while(sc.hasNextLine()) {
			try {
				String dt = sc.nextLine();
				inDate = df.parse(dt);
				break;
			}catch(Exception e) {
				e.printStackTrace();
				System.out.println();
			}
		}
		Calendar cal = Calendar.getInstance();
		cal.setTime(inDate);
		Calendar today  = Calendar.getInstance();
		long day = (cal.getTimeInMillis() - today.getTimeInMillis())/(60*60*1000);
		
		System.out.println(day+"��ŭ�� �ð����̰� �ֽ��ϴ�.");
	}
}
