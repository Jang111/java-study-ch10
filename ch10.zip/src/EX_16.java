import java.text.*;
import java.util.*;
public class EX_16 {

	public static void main(String[] args) {
		String msg = "Name : {0} \nTel : {1} \nAge : {2} \nBirthday : {3}";
		
		Object[] arguments = {"���¿�","010-6557-0266","22","20010103"};
		
		String result = MessageFormat.format(msg, arguments);
		System.out.println(result);
	}
}
