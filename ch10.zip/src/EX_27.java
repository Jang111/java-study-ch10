import java.time.*;
import java.time.format.*;

public class EX_27 {

	public static void main(String[] args) {
		DateTimeFormatter formatter = DateTimeFormatter.ofLocalizedDate(FormatStyle.FULL);
		String shortFormat = formatter.format(LocalDateTime.now());
		
		System.out.println(shortFormat);
	}
	
	
}
