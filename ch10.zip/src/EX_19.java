import java.text.*;
import java.util.*;
import java.io.*;

public class EX_19 {

	public static void main(String[] args) {
		String tableName = "CUST_INFO";
		String fileName = "D:\\data1.txt";
		String msg = "INSERT INTO "+tableName+" VALUES ({0},{1},{2},{3});";
		try {
		Scanner s = new Scanner(new File(fileName));
		String pattern = "{0},{1},{2},{3}";
		MessageFormat mf = new MessageFormat(pattern);
		while(s.hasNextLine()) {
			String line = s.nextLine();
			Object[] objs = mf.parse(line);
			System.out.println(MessageFormat.format(msg,objs));
		}
		s.close();
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}
}
