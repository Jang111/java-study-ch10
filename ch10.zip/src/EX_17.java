import java.text.*;
import java.util.*;
public class EX_17 {

	public static void main(String[] args) {
		String tableName = "CUST_INFO";
		String msg = "INSERT INTO" + tableName+" VALUES(''{0}'',''{1}'',''{2}'',''{3}'')";
		
		Object[][] arguments = {
				{"���¿�","02-123-1234","22","01-03"},
				{"ȫ�浿","02-123-1234","23","02-03"},	
		};
		for(int i=0;i<arguments.length;i++) {
			String result = MessageFormat.format(msg,arguments[i]);
			System.out.println(result);
		}
	}
}
